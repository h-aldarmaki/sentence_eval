Datasets downloaded from: http://qwone.com/~jason/20Newsgroups/
We crudely processed the files to remove headers, forwarded text, and signatures. 
