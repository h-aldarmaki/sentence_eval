The Microsoft Research Paraphrase Corpus was downloaded from: https://www.microsoft.com/en-us/download/details.aspx?id=52398

We modified the files in January 2018 to extract the sentences in the format given here.  
